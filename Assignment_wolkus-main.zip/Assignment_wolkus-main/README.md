# Assignment wolkus

A new Flutter project.

## Getting Started
 

- [Github Pages](https://github.com/yashvenrakumar/yashvenrakumar.github.io.git)
- [Web app link](https://yashvenrakumar.github.io/#/home)
 
  
 ## Instruction to used the flutter code :
 
``` 
 git  clone https://github.com/yashvenrakumar/Assignment_wolkus.git
 
 cd Assignment_wolkus
 
 code ...
 
 flutter run --no-sound-null-safety
 
```



# Data Analytics Charts
<img src="https://miro.medium.com/max/2732/1*RZlKYAWmotyHTvy2AG7GyQ.png" width="800" /> 
<img src="https://miro.medium.com/max/2732/1*5I0SVLMIPgrhm89cEAeOgQ.png" width="800"/>
<img src="https://miro.medium.com/max/2732/1*HtFFscVYXiFxFVbuH1HtpQ.png" width="800"/> 
<img src="https://miro.medium.com/max/2732/1*N3EG8Zu3PuWVtxpEtf_4ug.png" width="800"/>
<img src="https://miro.medium.com/max/2732/1*xHWkVWeM_-5CnOTh1XSzMg.png" width="800"/>
<img src="https://miro.medium.com/max/2732/1*ugACEnmwQXYdHuqz8FZDQQ.png" width="800"/>
<img src="https://miro.medium.com/max/2732/1*Cto_1F7W6rg7zpNDN6xUEg.png" width="800"/> 
<img src="https://miro.medium.com/max/2732/1*--BvAF6DSj3awcrF7AyolA.png" width="800"/>
